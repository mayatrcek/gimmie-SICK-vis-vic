---
name: Overworld Editorial
colors:
  surface: '#fff9ee'
  surface-dim: '#e1dac6'
  surface-bright: '#fff9ee'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf3df'
  surface-container: '#f5edd9'
  surface-container-high: '#f0e8d4'
  surface-container-highest: '#eae2ce'
  on-surface: '#1f1b0f'
  on-surface-variant: '#434654'
  inverse-surface: '#343023'
  inverse-on-surface: '#f8f0dc'
  outline: '#747685'
  outline-variant: '#c3c5d6'
  surface-tint: '#2355ce'
  primary: '#0043bb'
  on-primary: '#ffffff'
  primary-container: '#2e5dd6'
  on-primary-container: '#dfe4ff'
  inverse-primary: '#b5c4ff'
  secondary: '#b02f0c'
  on-secondary: '#ffffff'
  secondary-container: '#fc653f'
  on-secondary-container: '#5e1100'
  tertiary: '#17593c'
  on-tertiary: '#ffffff'
  tertiary-container: '#337253'
  on-tertiary-container: '#b2f4cd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b5c4ff'
  on-primary-fixed: '#00174d'
  on-primary-fixed-variant: '#003cab'
  secondary-fixed: '#ffdad2'
  secondary-fixed-dim: '#ffb4a2'
  on-secondary-fixed: '#3c0700'
  on-secondary-fixed-variant: '#8a1d00'
  tertiary-fixed: '#aff1ca'
  tertiary-fixed-dim: '#94d4af'
  on-tertiary-fixed: '#002112'
  on-tertiary-fixed-variant: '#0b5135'
  background: '#fff9ee'
  on-background: '#1f1b0f'
  surface-variant: '#eae2ce'
  parchment: '#F2EAD6'
  bone: '#FFFAEF'
  ink: '#161310'
  ink-soft: '#3A332A'
  border-tan: '#D9CDB3'
typography:
  display-xxl:
    fontFamily: Pixelify Sans
    fontSize: 128px
    fontWeight: '700'
    lineHeight: '0.92'
    letterSpacing: -0.02em
  display-xl:
    fontFamily: Pixelify Sans
    fontSize: 96px
    fontWeight: '700'
    lineHeight: '0.94'
    letterSpacing: -0.01em
  display-lg:
    fontFamily: Pixelify Sans
    fontSize: 72px
    fontWeight: '700'
    lineHeight: '0.96'
  headline-lg:
    fontFamily: Pixelify Sans
    fontSize: 44px
    fontWeight: '700'
    lineHeight: '1.02'
  headline-md:
    fontFamily: Pixelify Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.1'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.55'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.55'
  label-sm:
    fontFamily: VT323
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1'
    letterSpacing: 0.04em
  hud-md:
    fontFamily: VT323
    fontSize: 22px
    fontWeight: '400'
    lineHeight: '1'
    letterSpacing: 0.02em
  hud-sm:
    fontFamily: VT323
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1'
    letterSpacing: 0.02em
  display-lg-mobile:
    fontFamily: Pixelify Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: '0.96'
spacing:
  px: 2px
  xxs: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  xxxl: 64px
  bleed: 96px
  page-max: 1280px
---

## Brand & Style

The design system embodies an **Editorial Pixel-Art** aesthetic, merging the authoritative structure of a high-end broadsheet with the tactile nostalgia of 16-bit gaming. It is designed for worldbuilding, indie game hubs, and immersive storytelling environments that require a "physical" presence.

The style is defined by **Brutalist constraints** applied to classic editorial layouts. It rejects modern SaaS conventions—such as soft shadows, gradients, and rounded corners—in favor of:
- **Tactile Materiality:** Every element behaves like a physical object, using "press-into-shadow" interaction metaphors.
- **Digital Primitives:** Bold ink borders, notched corners, and chunky block shadows create a high-contrast, structured environment.
- **Atmospheric Utility:** The use of "HUD-style" marginalia in the gutters provides a functional, game-like layer to an otherwise clean, document-heavy interface.
- **Visual Texture:** Images are treated as pixelated artifacts with scanline overlays, while the background evokes warm, aged parchment.

## Colors

The palette is anchored in high-contrast, low-fatigue "analog" tones. 

- **Surfaces:** Use `parchment` for the primary page background to establish a warm, organic feel. `bone` is reserved for raised surfaces like cards and interactive inputs to create a clear visual hierarchy.
- **Ink & Typography:** Use `ink` for all primary borders, block shadows, and display type. `ink-soft` should be applied to secondary metadata or placeholders to reduce visual noise.
- **Accents:** `sky-cobalt` acts as the primary functional color for buttons and focus states. `sunset-vermillion` and `pine-moss` serve as semantic indicators for alerts and successes, respectively, while maintaining the saturated 16-bit character of the system.

## Typography

The system utilizes three distinct "registers" that must never be mixed within the same sentence:
1.  **Display (Pixelify Sans):** Used for all major headings. It is bold and impactful. Display XXL and XL are strictly for centered hero moments. Use negative tracking to maintain a tight, digital density.
2.  **Editorial (Inter):** The workhorse for long-form reading and standard UI text. It provides a neutral, highly legible contrast to the stylized pixel fonts.
3.  **HUD (VT323):** Used for buttons, labels, and marginalia. This register evokes technical game overlays. HUD text should often use positive tracking and uppercase for labels.

On mobile screens (<768px), headlines should clamp down significantly. The `display-lg-mobile` variant serves as the maximum size for small viewports.

## Layout & Spacing

The layout is built on a strict **4px/8px rhythm**, ensuring all components align to a pixel-perfect grid. 

- **Grid Model:** Use a 12-column fluid grid with a maximum width of `1280px`. 
- **Margins:** Desktop gutters are `64px`, while mobile gutters scale down to `24px`. 
- **Bleeds:** Hero images and major sections should utilize the `bleed` (96px) token to break the container and create asymmetrical interest.
- **Section Dividers:** Instead of simple lines, use "staircase" patterns (4px height, 8px steps) to separate major content blocks vertically.

## Elevation & Depth

This design system uses a physical **"Press-into-Shadow"** metaphor. There are no blurs, gradients, or soft glows.

- **Hard Block Shadows:** All depth is conveyed via solid `#161310` (ink) offsets. 
- **Levels:**
    - **Flush (0px):** For active or pressed states.
    - **Tap (2px):** Used for interactive chips or small input elements.
    - **Button (4px):** Standard elevation for primary interactive elements.
    - **Card (6px):** Standard depth for content containers.
    - **Featured (10px):** For hero cards or prominent callouts.
- **Shadow Tinting:** Focus states replace the ink shadow with a `4px` `sky-cobalt` shadow.

**Interaction Rule:** When an element is hovered or clicked, it must physically translate along the X and Y axis to meet its shadow. On click, the element translates by its shadow distance (e.g., `translate(4px, 4px)`) and the shadow is hidden, making the element appear flush with the parchment.

## Shapes

The shape language is strictly **geometric and sharp**.
- **Border Radius:** Always `0px`. No exceptions.
- **Notched Corners:** For cards and featured containers, use a `clip-path` to create 10px square notches on the top-left and bottom-right corners.
- **Borders:**
    - Standard UI (cards, buttons): `2px solid ink`.
    - Emphasis: `3px solid ink`.
    - Text-level dividers: `1px solid border-tan`.

## Components

- **Buttons:** Rectangular with `2px ink` borders and a `4px ink` block shadow. Labels are `Label SM` (VT323). Primary buttons use `sky-cobalt` background with white text; secondary buttons use `bone` background with `ink` text.
- **Cards:** `bone` surface with `2px ink` borders and `6px ink` block shadow. Utilize notched corners for featured content.
- **Input Fields:** `bone` background, `2px ink` border, `2px ink` block shadow. Text uses `HUD MD`. On focus, the shadow shifts to `4px sky-cobalt`.
- **Chips & Tags:** Small `bone` or `parchment` containers with `2px ink` borders and `2px` block shadows. Use `Label SM` for text.
- **Lists:** Use the "Quest Star" (12-point compass rose) as the bullet point, sized at `16px`.
- **Image Treatment:** All images must have `image-rendering: pixelated` applied. Overlay images with a scanline pattern (2px horizontal lines at 6% opacity) to maintain the retro-tech aesthetic.
- **Icons:** Use the **Phosphor Bold** set. Icons should always be paired with a `Label SM` text element for clarity.